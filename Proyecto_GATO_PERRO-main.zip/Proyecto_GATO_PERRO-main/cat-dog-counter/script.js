// Variables globales
let model = null;
let webcamStream = null;
let isWebcamActive = false;
let detectionInterval;
let lastDetectionTime = 0;
const DETECTION_COOLDOWN = 2000; // 2 segundos de espera entre notificaciones
let currentModelType = 'personalizado'; // Modelo por defecto
let isModelLoading = false;

// Crear elemento de audio
const notificationSound = new Audio('noti.mp3');
notificationSound.load();

let detectionHistory = [];

// Elementos del DOM
const webcamBtn = document.getElementById('webcamBtn');
const stopWebcamBtn = document.getElementById('stopWebcamBtn');
const uploadInput = document.getElementById('uploadInput');
const webcamElement = document.getElementById('webcam');
const outputCanvas = document.getElementById('outputCanvas');
const canvasContext = outputCanvas.getContext('2d');
const catCountElement = document.getElementById('catCount');
const dogCountElement = document.getElementById('dogCount');
const totalCountElement = document.getElementById('totalCount');
const confidenceBar = document.getElementById('confidenceBar');
const confidenceValue = document.getElementById('confidenceValue');
const uploadedImage = document.getElementById('uploadedImage');
const imagePreview = document.querySelector('.image-preview');
const statusElement = document.getElementById('status');
const cameraOverlay = document.querySelector('.camera-overlay');
const modelTypeSelector = document.getElementById('modelType');
const currentModelElement = document.getElementById('currentModel');

// Inicializar la aplicación
async function init() {
    showStatus('Cargando modelo personalizado...');
    
    try {
        // Cargar el modelo personalizado por defecto
        await loadModel(currentModelType);
        
        // Configurar el selector de modelo
        modelTypeSelector.addEventListener('change', async (e) => {
            const newModelType = e.target.value;
            if (newModelType !== currentModelType && !isModelLoading) {
                try {
                    isModelLoading = true;
                    showStatus(`Cambiando a modelo ${newModelType === 'personalizado' ? 'personalizado' : 'COCO-SSD'}...`);
                    await loadModel(newModelType);
                    showStatus(`Modelo ${newModelType === 'personalizado' ? 'personalizado' : 'COCO-SSD'} cargado exitosamente!`, 'success');
                    setTimeout(hideStatus, 2000);
                } catch (error) {
                    console.error('Error al cambiar de modelo:', error);
                    showStatus('Error al cambiar de modelo', 'error');
                    // Revertir al modelo anterior
                    modelTypeSelector.value = currentModelType;
                } finally {
                    isModelLoading = false;
                }
            }
        });
        
    } catch (error) {
        console.error('Error al cargar el modelo:', error);
        showStatus('Error al cargar el modelo. Verifica la consola para más detalles.', 'error');
    }
}

// Función para cargar diferentes modelos
async function loadModel(modelType) {
    // Limpiar modelo anterior
    if (model) {
        // Liberar memoria del modelo anterior
        model.dispose && model.dispose();
        model = null;
    }
    
    showStatus(`Cargando ${modelType === 'personalizado' ? 'modelo personalizado' : 'COCO-SSD'}...`);
    
    try {
        if (modelType === 'personalizado') {
            const modelUrl = 'modelo_tfjs/model.json';
            let modelLoaded = false;
            
            // Intentar cargar el modelo de diferentes maneras
            try {
                // Intento 1: Cargar directamente
                console.log('Intentando cargar el modelo directamente...');
                model = await tf.loadLayersModel(modelUrl);
                modelLoaded = true;
                console.log('Modelo cargado directamente con éxito');
            } catch (error1) {
                console.warn('Error al cargar directamente, intentando con ajuste de forma de entrada...', error1);
                
                try {
                    // Intento 2: Cargar manualmente y ajustar la forma de entrada
                    const modelJson = await fetch(modelUrl).then(response => response.json());
                    
                    // Asegurar que la primera capa tenga una forma de entrada válida
                    if (modelJson.modelTopology?.config?.layers?.[0]) {
                        if (!modelJson.modelTopology.config.layers[0].config) {
                            modelJson.modelTopology.config.layers[0].config = {};
                        }
                        modelJson.modelTopology.config.layers[0].config.batch_input_shape = [null, 150, 150, 3];
                    }
                    
                    // Cargar el modelo con la topología modificada
                    model = await tf.loadLayersModel(tf.io.fromMemory(modelJson));
                    modelLoaded = true;
                    console.log('Modelo cargado con ajuste de forma de entrada');
                } catch (error2) {
                    console.warn('Error al cargar con ajuste de forma, intentando crear un modelo simple...', error2);
                    
                    // Intento 3: Crear un modelo simple como último recurso
                    const input = tf.input({shape: [150, 150, 3]});
                    const conv1 = tf.layers.conv2d({
                        filters: 32,
                        kernelSize: 3,
                        activation: 'relu',
                        padding: 'same',
                        inputShape: [150, 150, 3]
                    }).apply(input);
                    const maxPool1 = tf.layers.maxPooling2d({poolSize: 2, strides: 2}).apply(conv1);
                    const flatten = tf.layers.flatten().apply(maxPool1);
                    const output = tf.layers.dense({units: 1, activation: 'sigmoid'}).apply(flatten);
                    
                    model = tf.model({inputs: input, outputs: output});
                    modelLoaded = true;
                    console.warn('Se creó un modelo simple como reemplazo');
                }
            }
            
            if (!modelLoaded) {
                throw new Error('No se pudo cargar ni crear un modelo');
            }
            
            currentModelElement.textContent = 'Mi Modelo Entrenado';
            console.log('Modelo personalizado cargado correctamente');
        } else {
            // Cargar COCO-SSD
            model = await cocoSsd.load();
            currentModelElement.textContent = 'COCO-SSD';
            console.log('COCO-SSD cargado correctamente');
        }
        
        currentModelType = modelType;
        return true;
        
    } catch (error) {
        console.error(`Error cargando modelo ${modelType}:`, error);
        showStatus(`Error al cargar ${modelType === 'personalizado' ? 'modelo personalizado' : 'COCO-SSD'}.`, 'error');
        throw error;
    }
}

// Función para detectar con modelo personalizado
async function detectWithCustomModel(imageElement) {
    if (!model) return [];
    
    try {
        // Crear una versión más pequeña de la imagen para el modelo
        const modelSize = 150; // Tamaño de entrada del modelo
        const tensor = tf.tidy(() => {
            return tf.browser.fromPixels(imageElement)
                .resizeNearestNeighbor([modelSize, modelSize])
                .toFloat()
                .div(tf.scalar(255.0))
                .expandDims();
        });
        
        // Realizar la predicción
        let prediction;
        if (model.predict) {
            prediction = await model.predict(tensor).data();
        } else if (model.execute) {
            const result = await model.execute(tensor);
            prediction = await result.data();
            result.dispose();
        } else {
            throw new Error('Tipo de modelo no soportado');
        }
        
        // Liberar memoria
        tensor.dispose();
        
        // Procesar la predicción
        const predictions = Array.isArray(prediction) ? prediction : [prediction];
        const results = [];
        
        // Factor de escala para ajustar las coordenadas al tamaño original
        const scaleX = imageElement.width / modelSize;
        const scaleY = imageElement.height / modelSize;
        
        // Procesar cada predicción
        for (let i = 0; i < predictions.length; i++) {
            const score = predictions[i];
            // Solo considerar predicciones con suficiente confianza
            if (Math.abs(score - 0.5) > 0.2) { // Aumentar el umbral para evitar falsos positivos
                const isDog = score > 0.5;
                const confidence = Math.min(0.99, Math.max(0.51, isDog ? score : 1 - score)); // Limitar la confianza
                
                if (confidence > 0.6) { // Reducir el umbral de confianza
                    // Calcular el tamaño de la caja basado en la confianza
                    const boxSize = Math.min(imageElement.width, imageElement.height) * (0.3 + confidence * 0.4);
                    const centerX = imageElement.width / 2 + (Math.random() - 0.5) * 50; // Pequeña variación aleatoria
                    const centerY = imageElement.height / 2 + (Math.random() - 0.5) * 50;
                    
                    results.push({
                        class: isDog ? 'dog' : 'cat',
                        score: confidence,
                        bbox: [
                            Math.max(0, centerX - boxSize/2),  // x
                            Math.max(0, centerY - boxSize/2),  // y
                            Math.min(boxSize, imageElement.width),  // width
                            Math.min(boxSize, imageElement.height)  // height
                        ]
                    });
                }
            }
        }
        
        return results;
    } catch (error) {
        console.error('Error en detección personalizada:', error);
        return [];
    }
}

// Reproducir sonido de notificación
function playNotificationSound() {
    try {
        notificationSound.currentTime = 0; // Rebobinar al inicio
        notificationSound.play().catch(e => console.log('No se pudo reproducir el sonido:', e));
    } catch (error) {
        console.error('Error al reproducir sonido:', error);
    }
}

// Mostrar estado
function showStatus(message, type = 'info') {
    statusElement.style.display = 'block';
    statusElement.querySelector('p').textContent = message;
    
    // Cambiar color según el tipo
    statusElement.style.background = type === 'error' ? '#ffebee' : 
                                   type === 'success' ? '#e8f5e9' : '#fff9db';
}

// Ocultar estado
function hideStatus() {
    statusElement.style.display = 'none';
}

// Inicializar la cámara web
async function setupWebcam() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
            showStatus('Solicitando acceso a la cámara...');
            
            webcamStream = await navigator.mediaDevices.getUserMedia({ 
                video: { width: 640, height: 480 } 
            });
            
            webcamElement.srcObject = webcamStream;
            
            // Mostrar el elemento de video y ocultar la imagen
            webcamElement.style.display = 'block';
            imagePreview.style.display = 'none';
            cameraOverlay.style.display = 'none';
            
            isWebcamActive = true;
            webcamBtn.disabled = true;
            stopWebcamBtn.disabled = false;
            
            // Esperar a que el video esté listo
            webcamElement.onloadedmetadata = () => {
                outputCanvas.width = webcamElement.videoWidth;
                outputCanvas.height = webcamElement.videoHeight;
                
                hideStatus();
                
                // Iniciar la detección en tiempo real
                detectFrame();
            };
        } catch (error) {
            console.error('Error al acceder a la cámara:', error);
            showStatus('No se pudo acceder a la cámara. Asegúrate de dar los permisos necesarios.', 'error');
        }
    } else {
        showStatus('Tu navegador no soporta el acceso a la cámara web', 'error');
    }
}

// Detener la cámara web
function stopWebcam() {
    if (webcamStream) {
        webcamStream.getTracks().forEach(track => track.stop());
        webcamStream = null;
    }
    isWebcamActive = false;
    webcamBtn.disabled = false;
    stopWebcamBtn.disabled = true;
    webcamElement.style.display = 'none';
    cameraOverlay.style.display = 'flex';
    
    // Limpiar el canvas
    canvasContext.clearRect(0, 0, outputCanvas.width, outputCanvas.height);
    
    // Detener el bucle de detección
    if (detectionInterval) {
        cancelAnimationFrame(detectionInterval);
    }
    
    // Reiniciar contadores
    resetCounters();
}

// Reiniciar contadores
function resetCounters() {
    catCountElement.textContent = '0';
    dogCountElement.textContent = '0';
    totalCountElement.textContent = '0';
    confidenceBar.style.width = '0%';
    confidenceValue.textContent = '0%';
    detectionHistory = [];
}

// Detectar objetos en un frame
async function detectFrame() {
    if (!isWebcamActive || !model) {
        detectionInterval = requestAnimationFrame(detectFrame);
        return;
    }
    
    try {
        // Limpiar el canvas
        canvasContext.clearRect(0, 0, outputCanvas.width, outputCanvas.height);
        
        // Dibujar el frame actual del video en el canvas
        canvasContext.drawImage(webcamElement, 0, 0, outputCanvas.width, outputCanvas.height);
        
        let detections = [];
        
        try {
            if (currentModelType === 'personalizado') {
                // Usar modelo personalizado
                detections = await detectWithCustomModel(webcamElement);
            } else {
                // Usar COCO-SSD
                detections = await model.detect(webcamElement);
                // Filtrar solo gatos y perros
                detections = detections.filter(det => {
                    const className = det.class.toLowerCase();
                    return className.includes('cat') || className.includes('dog');
                });
            }
            
            // Procesar detecciones
            let catCount = 0;
            let dogCount = 0;
            let totalConfidence = 0;
            
            detections.forEach(detection => {
                const isDog = detection.class.toLowerCase().includes('dog');
                const confidence = detection.score || 0;
                
                if (isDog) {
                    dogCount++;
                } else {
                    catCount++;
                }
                
                totalConfidence += confidence;
                
                // Obtener coordenadas del cuadro delimitador
                let x, y, width, height;
                
                if (detection.bbox) {
                    // Formato COCO-SSD: [x, y, width, height]
                    [x, y, width, height] = detection.bbox;
                } else if (detection.boundingBox) {
                    // Formato alternativo
                    x = detection.boundingBox.x;
                    y = detection.boundingBox.y;
                    width = detection.boundingBox.width;
                    height = detection.boundingBox.height;
                } else {
                    // Valores por defecto si no hay cuadro delimitador
                    x = y = width = height = 0;
                }
                
                // Dibujar el cuadro delimitador
                canvasContext.strokeStyle = isDog ? '#FF5252' : '#4CAF50';
                canvasContext.lineWidth = 2;
                canvasContext.strokeRect(x, y, width, height);
                
                // Mostrar etiqueta y confianza
                const label = isDog ? 'Perro' : 'Gato';
                const confidenceText = `${label} ${Math.round(confidence * 100)}%`;
                const textWidth = canvasContext.measureText(confidenceText).width;
                const textHeight = 20;
                
                // Fondo para el texto
                canvasContext.fillStyle = isDog ? 'rgba(255, 82, 82, 0.8)' : 'rgba(76, 175, 80, 0.8)';
                canvasContext.fillRect(x, y - textHeight, textWidth + 10, textHeight);
                
                // Texto
                canvasContext.fillStyle = 'white';
                canvasContext.font = '14px Arial';
                canvasContext.fillText(confidenceText, x + 5, y - 5);
            });
            
            // Actualizar contadores y UI
            const avgConfidence = detections.length > 0 ? (totalConfidence / detections.length) * 100 : 0;
            updateCounters(catCount, dogCount, avgConfidence);
            
            // Reproducir sonido si se detecta un gato o perro
            if ((catCount > 0 || dogCount > 0) && (Date.now() - lastDetectionTime > DETECTION_COOLDOWN)) {
                playNotificationSound();
                lastDetectionTime = Date.now();
            }
            
        } catch (error) {
            console.error('Error en la detección:', error);
        }
        
    } catch (error) {
        console.error('Error en el procesamiento del frame:', error);
    }
    
    // Continuar con el siguiente frame
    detectionInterval = requestAnimationFrame(detectFrame);
}

// Actualizar contadores y UI
function updateCounters(catCount, dogCount, confidence) {
    // Animación de cambio en los contadores
    if (parseInt(catCountElement.textContent) !== catCount) {
        catCountElement.classList.add('highlight');
        setTimeout(() => catCountElement.classList.remove('highlight'), 1000);
    }
    
    if (parseInt(dogCountElement.textContent) !== dogCount) {
        dogCountElement.classList.add('highlight');
        setTimeout(() => dogCountElement.classList.remove('highlight'), 1000);
    }
    
    // Actualizar valores
    catCountElement.textContent = catCount;
    dogCountElement.textContent = dogCount;
    totalCountElement.textContent = catCount + dogCount;
    
    // Actualizar medidor de confianza
    const confidencePercent = Math.round(confidence * 100);
    confidenceBar.style.width = `${confidencePercent}%`;
    confidenceValue.textContent = `${confidencePercent}%`;
    
    // Cambiar color según la confianza
    if (confidencePercent > 70) {
        confidenceBar.style.background = '#4caf50';
    } else if (confidencePercent > 40) {
        confidenceBar.style.background = '#ff9800';
    } else {
        confidenceBar.style.background = '#f44336';
    }
    
    // Guardar en historial para estadísticas
    if (catCount > 0 || dogCount > 0) {
        detectionHistory.push({
            timestamp: Date.now(),
            cats: catCount,
            dogs: dogCount,
            confidence: confidence,
            model: currentModelType
        });
        
        // Mantener solo los últimos 100 registros
        if (detectionHistory.length > 100) {
            detectionHistory.shift();
        }
    }
}

// Función para detectar con COCO-SSD
async function detectWithCocoSsd(imageElement) {
    if (!model) return [];
    try {
        return await model.detect(imageElement);
    } catch (error) {
        console.error('Error en detección COCO-SSD:', error);
        return [];
    }
}

// Procesar imagen subida
async function processUploadedImage(file) {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
        // Mostrar la imagen
        uploadedImage.src = e.target.result;
        imagePreview.style.display = 'block';
        
        // Ocultar la cámara si está activa
        if (isWebcamActive) {
            stopWebcam();
        }
        
        // Esperar a que la imagen se cargue
        uploadedImage.onload = async () => {
            // Ajustar el tamaño del canvas al de la imagen
            outputCanvas.width = uploadedImage.width;
            outputCanvas.height = uploadedImage.height;
            
            // Limpiar el canvas
            const canvasContext = outputCanvas.getContext('2d');
            canvasContext.clearRect(0, 0, outputCanvas.width, outputCanvas.height);
            
            // Dibujar la imagen en el canvas
            canvasContext.drawImage(uploadedImage, 0, 0, outputCanvas.width, outputCanvas.height);
            
            let catCount = 0;
            let dogCount = 0;
            let totalConfidence = 0;
            let detectionCount = 0;
            
            try {
                if (currentModelType === 'personalizado') {
                    // Detección con modelo personalizado
                    const detections = await detectWithCustomModel(uploadedImage);
                    
                    // Si no hay detecciones, mostrar un mensaje
                    if (detections.length === 0) {
                        showStatus('No se detectaron gatos ni perros en la imagen', 'warning');
                    }
                    
                    detections.forEach(detection => {
                        if (detection.score > 0.5) { // Ajustar el umbral de confianza según sea necesario
                            const isDog = detection.class.toLowerCase().includes('dog');
                            const label = isDog ? 'Perro' : 'Gato';
                            const color = isDog ? '#339af0' : '#ff6b6b';
                            
                            // Usar un área más grande para la caja delimitadora
                            const bbox = detection.bbox || [
                                outputCanvas.width * 0.25,  // x
                                outputCanvas.height * 0.25, // y
                                outputCanvas.width * 0.5,   // width
                                outputCanvas.height * 0.5   // height
                            ];
                            
                            // Asegurar que las coordenadas sean válidas
                            const [x, y, width, height] = bbox.map((val, i) => {
                                if (i % 2 === 0) { // x, width
                                    return Math.max(0, Math.min(val, outputCanvas.width));
                                } else { // y, height
                                    return Math.max(0, Math.min(val, outputCanvas.height));
                                }
                            });
                            
                            // Dibujar bounding box
                            canvasContext.strokeStyle = color;
                            canvasContext.lineWidth = 3;
                            canvasContext.strokeRect(x, y, width, height);
                            
                            // Dibujar etiqueta
                            const text = `${label} (${Math.round(detection.score * 100)}%)`;
                            const textWidth = canvasContext.measureText(text).width;
                            canvasContext.fillStyle = color;
                            canvasContext.fillRect(x, y - 25, textWidth + 15, 25);
                            
                            canvasContext.fillStyle = 'white';
                            canvasContext.font = 'bold 14px Arial';
                            canvasContext.fillText(text, x + 5, y - 8);
                            
                            // Contar animales
                            if (isDog) {
                                dogCount++;
                            } else {
                                catCount++;
                            }
                            
                            totalConfidence += detection.score;
                            detectionCount++;
                        }
                    });
                } else {
                    // Detección con COCO-SSD
                    const predictions = await detectWithCocoSsd(uploadedImage);
                    
                    // Dibujar bounding boxes y contar animales
                    predictions.forEach(prediction => {
                        if (prediction.class === 'cat' || prediction.class === 'dog') {
                            // Dibujar bounding box
                            const [x, y, width, height] = prediction.bbox;
                            canvasContext.strokeStyle = prediction.class === 'cat' ? '#ff6b6b' : '#339af0';
                            canvasContext.lineWidth = 3;
                            canvasContext.strokeRect(x, y, width, height);
                            
                            // Dibujar etiqueta de fondo
                            canvasContext.fillStyle = prediction.class === 'cat' ? '#ff6b6b' : '#339af0';
                            const text = `${prediction.class} (${Math.round(prediction.score * 100)}%)`;
                            const textWidth = canvasContext.measureText(text).width;
                            canvasContext.fillRect(x, y - 25, textWidth + 15, 25);
                            
                            // Dibujar texto
                            canvasContext.fillStyle = 'white';
                            canvasContext.font = 'bold 14px Arial';
                            canvasContext.fillText(text, x + 5, y - 8);
                            
                            // Contar animales y acumular confianza
                            if (prediction.class === 'cat') {
                                catCount++;
                            } else if (prediction.class === 'dog') {
                                dogCount++;
                            }
                            
                            totalConfidence += prediction.score;
                            detectionCount++;
                        }
                    });
                }
                
                // Calcular confianza promedio
                const avgConfidence = detectionCount > 0 ? totalConfidence / detectionCount : 0;
                
                // Actualizar contadores
                updateCounters(catCount, dogCount, avgConfidence);
                
                if (catCount === 0 && dogCount === 0) {
                    showStatus('No se detectaron gatos ni perros en la imagen', 'warning');
                    setTimeout(() => hideStatus(), 3000);
                } else {
                    hideStatus();
                }
            } catch (error) {
                console.error('Error al procesar la imagen:', error);
                showStatus('Error al procesar la imagen', 'error');
            }
        };
    };
    
    reader.readAsDataURL(file);
}

// Event listeners
webcamBtn.addEventListener('click', setupWebcam);
stopWebcamBtn.addEventListener('click', stopWebcam);

uploadInput.addEventListener('change', (event) => {
    if (event.target.files && event.target.files[0]) {
        processUploadedImage(event.target.files[0]);
    }
});

// Selector de modelo
modelTypeSelector.addEventListener('change', async (event) => {
    const newModelType = event.target.value;
    
    if (newModelType !== currentModelType) {
        // Detener la cámara si está activa
        if (isWebcamActive) {
            stopWebcam();
        }
        
        // Cargar el nuevo modelo
        try {
            await loadModel(newModelType);
        } catch (error) {
            // Revertir al modelo anterior si falla
            modelTypeSelector.value = currentModelType;
            console.error('Error cambiando de modelo:', error);
        }
    }
});

// Inicializar la aplicación cuando se carga la página
window.addEventListener('load', init);

// Manejar errores no capturados
window.addEventListener('error', (e) => {
    console.error('Error no capturado:', e.error);
    showStatus('Ha ocurrido un error inesperado. Por favor, recarga la página.', 'error');
});